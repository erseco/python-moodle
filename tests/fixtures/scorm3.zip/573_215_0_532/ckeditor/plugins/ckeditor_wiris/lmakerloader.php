<?php

use App\Kernel;

umask(0002);

defined('APPLICATION_PATH') || define('APPLICATION_PATH', realpath(__DIR__.'/../../../../../../../../../application'));

require_once realpath(APPLICATION_PATH.'/../../../autoload.php');

(new Symfony\Component\Dotenv\Dotenv())->usePutenv()->load(APPLICATION_PATH.'/../../../../.env');

$env = $_SERVER['APP_ENV'];
$debug = (bool) ($_SERVER['APP_DEBUG'] ?? ('prod' !== $env));

$kernel = new Kernel($_SERVER['APP_ENV'], $debug);

$kernel->boot();

\Doctrine\Common\Annotations\AnnotationRegistry::registerAutoloadNamespace(
    "JMS\Serializer\Annotation",
    __DIR__.'/../../../jms/serializer/src'
);
\Doctrine\Common\Annotations\AnnotationRegistry::registerAutoloadNamespace(
    "LMaker\Annotations\Annotation"
);

set_exception_handler(function () {
    return;
});

set_error_handler(function () {
    return;
});

$containerLMaker = $kernel->getContainer()->get(\Psr\Container\ContainerInterface::class);

Zend_Registry::set('container', $containerLMaker);
