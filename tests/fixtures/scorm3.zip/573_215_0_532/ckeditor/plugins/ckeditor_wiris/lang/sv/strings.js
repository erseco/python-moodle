var strings = new Array();
strings['cancel'] = 'Avbryt';
strings['accept'] = 'OK';
strings['manual'] = 'Bruksanvisning';
strings['latex'] = 'LaTeX';