var strings = new Array();
strings['cancel'] = 'Abbrechen';
strings['accept'] = 'OK';
strings['manual'] = 'Handbuch';
strings['latex'] = 'LaTeX';