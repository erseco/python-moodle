CKEDITOR.plugins.setLang( 'ntxclasscombo', 'es', {
	label: 'Clases',
	panelTitle: 'Clases',
	panelTitle1: 'Block Styles',
	panelTitle2: 'Insertar clases',
	panelTitle3: 'Object Styles'
} );
