CKEDITOR.plugins.setLang( 'ntxclasscombo', 'en', {
	label: 'Class',
	panelTitle: 'Class',
	panelTitle1: 'Block Styles',
	panelTitle2: 'Insert classes',
	panelTitle3: 'Object Styles'
} );
