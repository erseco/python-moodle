CKEDITOR.plugins.setLang( 'ntxcomponentcombo', 'en', {
	label: 'Components',
	panelTitle: 'Components',
	panelTitle1: 'Block Styles',
	panelTitle2: 'Insert link',
	panelTitle3: 'Object Styles'
} );
