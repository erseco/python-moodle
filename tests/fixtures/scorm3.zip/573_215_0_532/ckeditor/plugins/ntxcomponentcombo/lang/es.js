CKEDITOR.plugins.setLang( 'ntxcomponentcombo', 'es', {
	label: 'Componentes',
	panelTitle: 'Componentes',
	panelTitle1: 'Block Styles',
	panelTitle2: 'Insertar enlace',
	panelTitle3: 'Object Styles'
} );
