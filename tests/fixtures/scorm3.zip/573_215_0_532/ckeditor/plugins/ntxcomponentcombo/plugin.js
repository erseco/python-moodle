( function() {
    'use strict';

    CKEDITOR.plugins.add( 'ntxcomponentcombo', {
        requires: 'richcombo',
        lang: 'en,es',
        init: function( editor ) {
            var config = editor.config,
                lang = editor.lang.ntxcomponentcombo,
                stylesDefinitions = config.ntxcomponentcomboConfig
            ;
            if ( !stylesDefinitions )
                return;


            editor.ui.addRichCombo( 'NtxComponentCombo', {
                label: lang.label,
                title: lang.panelTitle,
                toolbar: 'styles,11',

                panel: {
                    css: [ CKEDITOR.skin.getPath( 'editor' ) ].concat( config.contentsCss ),
                    multiSelect: true,
                    attributes: { 'aria-label': lang.panelTitle }
                },

                init: function() {
                    var i, count;
                    for ( i = 0, count = stylesDefinitions.length; i < count; i++ ) {
                        this.add(stylesDefinitions[i].name,stylesDefinitions[i].name);
                    }
                    this.commit();
                },

                onClick: function( value ) {
                    var obj;
                    editor.focus();
                    editor.fire( 'saveSnapshot' );
                    
                    for(var i = 0; i < stylesDefinitions.length; i++){
                        if(stylesDefinitions[i].name === value){
                            obj = stylesDefinitions[i];
                        }
                    }
                    editor.fire("pluginNtxComponent",{"editor": editor, "obj":obj, "callback": insertComponentIntoSelection});
                    editor.fire( 'saveSnapshot' );
                }
            } );
        }
    } );
    function insertComponentIntoSelection(editor, html) {
        var idHtmlComponent = "a";
        var idComponent = "b";
        
        var ranges = editor.getSelection().getRanges();
        var rangesToSelect = [];
        var range;
        var nestedLinks;        
        for (var i = 0; i < ranges.length; i++ ) {
            range = ranges[ i ];
            // Editable links nested within current range should be removed, so that the link is applied to whole selection.
            nestedLinks = range._find( 'a' );
            for (var j = 0; j < nestedLinks.length; j++ ) {
                nestedLinks[ j ].remove( true );
            }
            
            editor.insertHtml(html);


            rangesToSelect.push( range );
        }

        editor.getSelection().selectRanges( rangesToSelect );
    }
} )();
