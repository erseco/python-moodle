﻿CKEDITOR.plugins.setLang('jsplus_table_new', 'ru', {

    jsplus_custom_templates_title: 'Вставить пользовательский шаблон',

    jsplus_templates_title: 'Вставить шаблон',
    jsplus_bootstrap_templates_title: 'Вставить строку Bootstrap у курсора',
    jsplus_foundation_templates_title: 'Вставить строку Foundation у курсора',

    jsplus_bootstrap_row_add_up_title: 'Вставить строку Bootstrap выше',
    jsplus_bootstrap_row_add_down_title: 'Вставить строку Bootstrap ниже',
    jsplus_foundation_row_add_up_title: 'Вставить строку Foundation выше',
    jsplus_foundation_row_add_down_title: 'Вставить строку Foundation ниже',

    jsplus_table_title: 'Вставить таблицу',
    jsplus_bootstrap_table_title: 'Вставить таблицу Bootstrap',
    jsplus_foundation_table_title: 'Вставить таблицу Foundation',

    jsplus_alert_title: 'Вставить сообщение',
    jsplus_bootstrap_alert_title: 'Вставить сообщение Bootstrap',
    jsplus_foundation_alert_title: 'Вставить сообщение Foundation',

    jsplus_table_width_100: 'Ширина 100%',
    jsplus_table_add_header: 'Заголовок',
    jsplus_bootstrap_table_striped: 'Полосатая',
    jsplus_bootstrap_table_bordered: 'С границами',
    jsplus_bootstrap_table_condensed: 'Компактная',
    jsplus_table_class: 'Доп. класс',
    jsplus_table_style: 'Доп. стиль',

    select_element_first: 'Сначала выберите элемент',

    btn_ok: "OK",
    btn_cancel: "Отмена"
} );