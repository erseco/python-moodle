CKEDITOR.plugins.add('ntxdeletediv', {
	init: function (editor) {
		editor.on('contentDom', function () {
			var editable = editor.editable();

			editable.attachListener(editable, 'keydown', function (evt) {
				var keyCode = evt.data.getKey(); // Obtiene el código de la tecla presionada

				var selection = editor.getSelection();
				var range = selection.getRanges()[0];
				if (!range.collapsed) {
					return; // Si hay una selección, no hagas nada
				}
				if (keyCode === 8) { // Tecla de borrar

					var currentNode = range.endContainer;
					console.log('currentNode', currentNode)

						// Si es un nodo de texto y no es el comienzo del nodo, no subas más
						if (currentNode.type == CKEDITOR.NODE_TEXT && range.endOffset !== 0) {
							return;
						}
						// Obtener el previousElementSibling
						var previousElementSibling = currentNode.getPrevious(function (node) {
							return node.type == CKEDITOR.NODE_ELEMENT;
						});

						// Verificar si existe el previousElementSibling y luego eliminarlo
						if (previousElementSibling && previousElementSibling.is('div')) {
							previousElementSibling.remove();
							evt.cancel();
							return;
						}
				}
			});
		});
	}
});

