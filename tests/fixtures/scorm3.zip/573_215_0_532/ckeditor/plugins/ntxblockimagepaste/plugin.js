CKEDITOR.plugins.add('ntxblockimagepaste', {
	init: function (editor) {

		function replaceImgText(html) {
			var ret = html.replace(/<img[^>]*src="data:image\/(bmp|dds|gif|jpg|jpeg|png|psd|pspimage|tga|thm|tif|tiff|yuv|ai|eps|ps|svg);base64,.*?"[^>]*>/gi, function (img) {
				editor.fire("pluginNtxError", { "editor": editor, "error": 'pasteImage' });
				return '';
			});

			return ret;
		}

		editor.on('paste', function (e) {
			var html = e.data.dataValue;
			var dataTransfer = e.data.dataTransfer.$.files.length;
			if(dataTransfer){
				editor.fire("pluginNtxError", { "editor": editor, "error": 'pasteImage' });
			}else {
				if (!html) {
					return;
				}
				e.data.dataValue = replaceImgText(html);
			}
			

		});

	} 
});