CKEDITOR.plugins.setLang( 'ntxlinkcombo', 'en', {
	label: 'Links',
	panelTitle: 'Links',
	panelTitle1: 'Block Styles',
	panelTitle2: 'Insert link',
	panelTitle3: 'Object Styles'
} );
