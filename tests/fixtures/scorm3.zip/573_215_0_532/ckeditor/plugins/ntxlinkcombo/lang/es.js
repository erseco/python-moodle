CKEDITOR.plugins.setLang( 'ntxlinkcombo', 'es', {
	label: 'Enlaces',
	panelTitle: 'Enlaces',
	panelTitle1: 'Block Styles',
	panelTitle2: 'Insertar enlace',
	panelTitle3: 'Object Styles'
} );
