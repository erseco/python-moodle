( function() {
    'use strict';

    CKEDITOR.plugins.add( 'ntxlinkcombo', {
        requires: 'richcombo',
        lang: 'en,es',
        init: function( editor ) {
            var config = editor.config,
                lang = editor.lang.ntxlinkcombo,
                stylesDefinitions = config.ntxlinkcomboConfig,
                required = 'a[title,href]'
            ;
            if ( !stylesDefinitions )
                return;


            editor.ui.addRichCombo( 'NtxLinkCombo', {
                label: lang.label,
                title: lang.panelTitle,
                toolbar: 'styles,11',
                requiredContent: required,

                panel: {
                    css: [ CKEDITOR.skin.getPath( 'editor' ) ].concat( config.contentsCss ),
                    multiSelect: true,
                    attributes: { 'aria-label': lang.panelTitle }
                },

                init: function() {
                    var i, count;
                    for ( i = 0, count = stylesDefinitions.length; i < count; i++ ) {
                        this.add(stylesDefinitions[i].name,stylesDefinitions[i].name);
                    }
                    this.commit();
                },

                onClick: function( value ) {
                    var obj = {};
                    var newId = "xxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx".replace(/[xy]/g, function (c) {
                        var r = Math.random() * 16|0, v = c == "x" ? r : (r&0x3|0x8);
                        return v.toString(16);
                    });
                    editor.focus();
                    editor.fire( 'saveSnapshot' );
                    
                    for(var i = 0; i < stylesDefinitions.length; i++){
                        if(stylesDefinitions[i].name === value){
                            obj = JSON.parse(JSON.stringify(stylesDefinitions[i]));
                        }
                    }
                    for ( var attr in obj.attributes) {
                        obj.attributes[attr] = obj.attributes[attr].split("(replace)").join(newId);
                    }
                    insertLinksIntoSelection(editor, obj);

                    editor.fire( 'saveSnapshot' );
                }
            } );
        }
    } );
    function insertLinksIntoSelection( editor, data ) {
        var selection = editor.getSelection();
        var selector = selection.getStartElement();
        var element;
        var insertMode = false;
        
        if(selector) {
            element = selector.getAscendant( 'a', true );
        }
        
        if ( !element || element.getName() != 'a' ) {
            element = editor.document.createElement( 'a' );
            for (var attr in data.attributes) {
                element.setAttribute(attr, data.attributes[attr]);
            }
            if(selection) {
                element.setText(selection.getSelectedText());
            }
            insertMode = true;
        }
        if(insertMode) {
            editor.insertElement(element);
        }
    }
} )();
