CKEDITOR.plugins.add( 'ntximage', {
    lang: 'en,es',
    icons: 'ntximage',
    init: function( editor ) {
        var pluginName = 'ntximage';
        var allowed = 'img[alt,class,!src]{border-style,border-width,float,height,margin,margin-bottom,margin-left,margin-right,margin-top,width}';
        var required = 'img[alt,src]';
        var config = editor.config;
        var dataImg = config.ntximage[0];
        editor.ui.addButton( 'ntximage', {
            label: editor.lang.common.image,
            command: pluginName,
            toolbar: 'insert,10'
        });
        editor.addCommand(pluginName,{
            exec: function( editor ){
                var textSelected = editor.getSelection().getSelectedText();
                var img;
                var newId = "xxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx".replace(/[xy]/g, function (c) {
                    var r = Math.random() * 16|0, v = c == "x" ? r : (r&0x3|0x8);
                    return v.toString(16);
                });
                var newDataImg = JSON.parse(JSON.stringify(dataImg));
                if(textSelected.length == 0 ){
                    img = editor.document.createElement(newDataImg.element);
                    for ( var attr in newDataImg.attributes) {
                        newDataImg.attributes[attr] = newDataImg.attributes[attr].split("(replace)").join(newId);
                        if(attr === "src" && !newDataImg.attributes[attr]){
                            newDataImg.attributes[attr] = "http://dummyimage.com/20x20/000/fff";
                        }
                        img.setAttribute(attr, newDataImg.attributes[attr]);
                    }
                    editor.insertElement(img);
                    img.$.click();
                }    
           },
           allowedContent: allowed,
           requiredContent: required,
           contentTransformations: [
                [ 'img{width}: sizeToStyle', 'img[width]: sizeToAttribute' ],
                [ 'img{float}: alignmentToStyle', 'img[align]: alignmentToAttribute' ]
            ]
        });
    }
});
