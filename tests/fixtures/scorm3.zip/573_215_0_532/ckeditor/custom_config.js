/**
 * @license Copyright (c) 2003-2017,CKSource - Frederico Knabben. All rights reserved.
 * For licensing,see LICENSE.md or http://ckeditor.com/license
 */

CKEDITOR.editorConfig = function( config ) {
	// Define changes to default configuration here.
	// For complete reference see:
	// http://docs.ckeditor.com/#!/api/CKEDITOR.config

	//config.extraPlugins = 'ntximage,ntxclasscombo,ntxlinkcombo,ntxcomponentcombo,jsplus_table_new,jsplus_table_conf,jsplus_table_row_conf,jsplus_table_col_conf,jsplus_table_cell_conf,jsplus_table_row_move_up,jsplus_table_row_move_down,jsplus_table_col_move_left,jsplus_table_col_move_right,jsplus_table_add_row_up,jsplus_table_add_row_down,jsplus_table_add_col_left,jsplus_table_add_col_right,jsplus_table_add_cell_left,jsplus_table_add_cell_right,jsplus_table_delete_col,jsplus_table_delete_row,jsplus_table_delete_cell,jsplus_table_merge_cells,jsplus_table_merge_cell_right,jsplus_table_merge_cell_down,jsplus_table_split_cell_hor,jsplus_table_split_cell_vert,ckeditor_wiris';
	config.extraPlugins = 'ntxblockimagepaste,ntxdeletediv';
	config.toolbar_Netex = [
		{name:'tools'},
		{name:'document', items:['Sourcedialog'] },
		{name:'clipboard', items:['Cut','Copy','Paste','PasteText','PasteFromWord','-','Undo','Redo'] },
		{name:'editing', items:['Scayt'] },
		{name:'links'},
		{name:'forms'},
		{name:'basicstyles', items:['Bold','Italic','Underline','Strike','Subscript','Superscript','-','RemoveFormat'] },
		'/',
		{name:'paragraph', items:['JustifyLeft','JustifyCenter','JustifyRight','JustifyBlock','-','NumberedList','BulletedList','-','Outdent','Indent','-','Blockquote'] },
		{name:'insert', items:['ntximage','SpecialChar','ckeditor_wiris_formulaEditor','ckeditor_mathquill'] },
		{name:'colors', items:['TextColor','BGColor']},
		'/',
		{name:'styles', items:['Format','Font','FontSize','lineheight','letterspacing']},
		//{name:'NTX', items:['NtxClassCombo','NtxLinkCombo','NtxComponentCombo']},
		'/',
        //{name:'advancedtable', items:['jsplus_table_new','jsplus_table_conf','jsplus_table_row_conf','jsplus_table_col_conf','jsplus_table_cell_conf','jsplus_table_row_move_up','jsplus_table_row_move_down','jsplus_table_col_move_left','jsplus_table_col_move_right','jsplus_table_add_row_up','jsplus_table_add_row_down','jsplus_table_add_col_left','jsplus_table_add_col_right','jsplus_table_add_cell_left','jsplus_table_add_cell_right','jsplus_table_delete_col','jsplus_table_delete_row','jsplus_table_delete_cell','jsplus_table_merge_cells','jsplus_table_merge_cell_right','jsplus_table_merge_cell_down','jsplus_table_split_cell_hor','jsplus_table_split_cell_vert']},
        {name:'about'}
    ];
    config.toolbar = "Netex";
	// Remove some buttons provided by the standard plugins,which are
	// not needed in the Standard(s) toolbar.
	config.removeButtons = 'HorizontalRule,Table,Anchor,Styles,About';
	// Set the most common block elements.
	config.format_tags = 'p;h1;h2;h3;h4;h5;h6;div';
	config.allowedContent = true;
	// Simplify the dialog windows.
	config.removeDialogTabs = 'image:advanced;link:advanced';
	config.fillEmptyBlocks = false;
	config.autoParagraph = false;
	config.enterMode = CKEDITOR.ENTER_DIV;
};
