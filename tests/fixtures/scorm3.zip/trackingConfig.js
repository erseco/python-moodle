var TrackingConfig = {
    "success_status": "passed",
    "unsuccess_status": "failed",
    "send_score": "true",
    "send_status": "true",
    "send_interactions": "true",
    "send_objectives": "true",
    "mastery_score": "80",
    "type": "scorm_2004"
}